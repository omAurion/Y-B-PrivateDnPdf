window.jQuery = require("jquery");
require("bootstrap");
import $ from "jquery";
import _ from "lodash";
import React from 'react';
import {render} from 'react-dom';
import Moment from 'moment';
var momentLocalizer = require('react-widgets/lib/localizers/moment')
momentLocalizer(Moment);
import {Route, NotFoundRoute, DefaultRoute, RouteHandler, Link} from "react-router";
import Router from "react-router";
import Login from "./login-form.jsx";
import Dashboard from "./dashboard";
import CreditForm from "./credit";
import OffersForm from "./offers";
import printProsp from "./printProsp"
import printFirst from "./printFirst"
import TermsForm from "./terms";
import content, {loadContent} from "./content.js";
var MediaQuery = require('react-responsive');
var urlResult = "org";
var earned = "Points Earned :";
var sType = 101;
var menuIcon = "";
var pdfDownloadLink = "";

var fdStatementTablePrint =  [
    {
        "transactionDate": "",
        "description": "",
        "amount": "",
        "transactionCode": ""
    }
];

var Search = React.createClass({
    getInitialState: function() {
        return { childVisible: false };
    },
    onClick: function() {
        this.setState({childVisible: !this.state.childVisible});
    },

    componentDidMount()
    {
        var url = window.location.href;//"file:///D:/facebook/YesBank/build/index.html?p1=dup&p2=ib#/" //or window.location.href for current url
        var capturedP1 = "";
        var capturedP2 = "";
        var resCapturedP1 = url.match(/p1/g);
        var resCapturedP2 = url.match(/p2/g);

        if(resCapturedP1 != null){
            capturedP1 = /p1=([^&]+)/.exec(url)[1];
        }
        if(resCapturedP2 != null){
            capturedP2 = /p2=([^&]+)/.exec(url)[1];
        }

        if(capturedP2 === "AE4736231BB94A28#/")
        {
            urlResult = "ib";
        }
        else if(capturedP1 === "DFD344B10466D628")
        {
            urlResult = "dup"
        }
        else
        {
            urlResult = "org"
        }

    },
    formatCurrency(nStr)
    {
        nStr += '';
        var x = nStr.split('.');
        var x1 = x[0];
        var x2 = x.length > 1 ? ('.' + x[1]): '';
        if
        (
            x2.length == 0)
        {
            x2 = '.00';
        }
        else if
        (
            x2.length == 2)
        {
            x2 = '.' + x[1] + '0';
        }

        var rgx = /(\d+)(\d{3})/;
        var z = 0;
        var len = String(x1).length;
        var num = parseInt((len/2)-1);

        while (rgx.test(x1))
        {
            if(z > 0)
            {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            }
            else
            {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
                rgx = /(\d+)(\d{2})/;
            }
            z++;
            num--;

            if(num == 0)
            {
                break;
            }
        }
        return x1+x2;
    },

    isPromom(){

        var customer = content.CUSTOMER;
        var offerImg;
        var link1 = "";
        var link2 = "";
        var link3 = "";
        var text1 = "";
        var text2 = "";
        var text3 = "";
        var isOrgOffer = "false";
        var isDupText = "false";

        if(customer.hasOwnProperty("offers"))
        {
            offerImg = customer.offers;
            if(offerImg.hasOwnProperty("link1"))
            {
                link1 = offerImg.link1;
            }
            if(offerImg.hasOwnProperty("link2"))
            {
                link2 = offerImg.link2;
            }
            if(offerImg.hasOwnProperty("link3"))
            {
                link3 = offerImg.link3;
            }
            if(offerImg.hasOwnProperty("link1m"))
            {
                menuIcon = offerImg.link1m;
            }
            if(offerImg.hasOwnProperty("text1"))
            {
                text1 = offerImg.text1;
            }
            if(offerImg.hasOwnProperty("text2"))
            {
                text2 = offerImg.text2;
            }
            if(offerImg.hasOwnProperty("text3"))
            {
                text3 = offerImg.text3;
            }
        }

        if(link1 == "" && link2=="" && link3 =="")
        {
            isOrgOffer = "false";
        }
        else{
            isOrgOffer = "true";
        }

        if(text1 == "" && text2=="" && text3 =="")
        {
            isDupText = "false";
        }
        else{
            isDupText = "true";
        }

        if(urlResult === "org")
        {
            if(isOrgOffer == "true")
            {
                return (
                    <li  id="offersTab" role="presentation">
                        <Link to="offers" className="linkAnchorM"><p onClick={this.onClick}>YES PRIVILEGES</p></Link>
                    </li>
                );
            }
            else{
                return null;
            }
        }
        else if(urlResult === "dup")
        {
            if(isDupText == "true")
            {
                return (
                    <li  id="offersTab" role="presentation">
                        <Link to="offers" className="linkAnchorM"><p onClick={this.onClick}>YES PRIVILEGES</p></Link>
                    </li>
                );
            }
            else{
                return null;
            }
        }
        else{
            return null;
        }
    },

    onPrintm() {
        let customer = content.CUSTOMER;
        if(customer.hasOwnProperty("statementType")){
            sType = customer.statementType;
        }
        if(sType == 103 || sType == 104)
        {
            earned = "Cashback Earned :";
        }
        else
        {
            earned = "Points Earned :";
        }
        var MyCardPage = content.CUSTOMER.myCardPage;
        var statementtable = [];
        if(MyCardPage.hasOwnProperty("TransactionsInfo")) {
            let TransactionsInfo = MyCardPage.TransactionsInfo
            if (TransactionsInfo.hasOwnProperty("transaction")) {
                let tempStatementtable = TransactionsInfo.transaction;
                let newTransactionData = [];
                if(tempStatementtable.length > 1)
                {
                    for(var sdate in tempStatementtable)
                    {
                        let zTransaction = tempStatementtable[sdate];
                        let zdate = zTransaction.transactionDate;
                        zdate = (zdate).split("-");
                        zdate = zdate[2]+zdate[1]+zdate[0];
                        newTransactionData.push({
                            sortDate:(zTransaction.amount==0)?"":zdate,
                            transactionDate:zTransaction.transactionDate,
                            transactionCode:zTransaction.transactionCode,
                            description:zTransaction.description,
                            CardSequenceNumber:zTransaction.CardSequenceNumber,
                            amount:(zTransaction.amount==0)?"":zTransaction.amount,
                            transactionType:zTransaction.transactionType,
                        })
                    }
                }
                else{
                    let zTransaction = tempStatementtable;
                    let zdate = zTransaction.transactionDate;
                    zdate = (zdate).split("-");
                    zdate = zdate[2]+zdate[1]+zdate[0];
                    newTransactionData.push({
                        sortDate:(zTransaction.amount==0)?"":zdate,
                        transactionDate:zTransaction.transactionDate,
                        transactionCode:zTransaction.transactionCode,
                        description:zTransaction.description,
                        CardSequenceNumber:zTransaction.CardSequenceNumber,
                        amount:(zTransaction.amount==0)?"":zTransaction.amount,
                        transactionType:zTransaction.transactionType,
                    })
                }
                statementtable = newTransactionData;
            }
            else
            {
                statementtable = fdStatementTablePrint;
            }
        }
        else
        {
            statementtable = fdStatementTablePrint;
        }

        let homePageData = content.CUSTOMER;
        printFirst(statementtable,homePageData,earned);

        /*
         For First Print
         printFirst(dataToPrint,homePageData);

         For Prosperity Print
         printProsp(dataToPrint,homePageData);
         */
    },

    render: function() {
        var customer = content.CUSTOMER;
        if(customer.hasOwnProperty("printpath"))
        {
            let printpath = customer.printpath;
            if(printpath.hasOwnProperty("printpathlocation"))
            {
                pdfDownloadLink = "D:/prints/"+printpath.printpathlocation;
            }
        }
        return (
            <div className="row rightAlignStyle1">
                <div className="col-xs-9">
                </div>
                <div className="col-xs-2">
                </div>
                <label className="navMIconStyle" onClick={this.onClick}></label>    
                {
                    this.state.childVisible
                        ? (
                        <ul className="navMobile">
                            <li id="overviewTab"  role="presentation">
                                <Link to="dashboard" className="linkAnchorM"><p onClick={this.onClick}>SUMMARY</p></Link>
                            </li>
                            <li  id="myCardTab" role="presentation">
                                <Link to="credit" className="linkAnchorM"><p onClick={this.onClick}>STATEMENT DETAILS</p></Link>
                            </li>
                            {this.isPromom()}
                            <li  id="termsTab"  role="presentation">
                                <Link to="terms" className="linkAnchorM"><p onClick={this.onClick}>TERMS &amp; CONDITIONS</p></Link>
                            </li>
                        </ul>
                    )
                        : null
                }
            </div>
        );
    }
});

var PromoLi = React.createClass({
    render: function() {
        var customer = content.CUSTOMER;
        var offerImg;
        var link1 = "";
        var link2 = "";
        var link3 = "";
        var text1 = "";
        var text2 = "";
        var text3 = "";
        var isOrgOffer = "false";
        var isDupText = "false";

        if(customer.hasOwnProperty("offers"))
        {
            offerImg = customer.offers;
            if(offerImg.hasOwnProperty("link1"))
            {
                link1 = offerImg.link1;
            }
            if(offerImg.hasOwnProperty("link2"))
            {
                link2 = offerImg.link2;
            }
            if(offerImg.hasOwnProperty("link3"))
            {
                link3 = offerImg.link3;
            }
            if(offerImg.hasOwnProperty("text1"))
            {
                text1 = offerImg.text1;
            }
            if(offerImg.hasOwnProperty("text2"))
            {
                text2 = offerImg.text2;
            }
            if(offerImg.hasOwnProperty("text3"))
            {
                text3 = offerImg.text3;
            }
        }

        if(link1 == "" && link2=="" && link3 =="")
        {
            isOrgOffer = "false";
        }
        else{
            isOrgOffer = "true";
        }

        if(text1 == "" && text2=="" && text3 =="")
        {
            isDupText = "false";
        }
        else{
            isDupText = "true";
        }

        if(urlResult === "org")
        {
            if(isOrgOffer == "true")
            {
                return (
                    <li  id="offersTab" role="presentation">
                        <Link to="offers" className="linkAnchor">YES PRIVILEGES</Link>
                    </li>
                );
            }
            else{
                return null;
            }
        }
        else if(urlResult === "dup")
        {
            if(isDupText == "true")
            {
                return (
                    <li  id="offersTab" role="presentation">
                        <Link to="offers" className="linkAnchor">YES PRIVILEGES</Link>
                    </li>
                );
            }
            else{
                return null;
            }
        }
        else{
            return null;
        }
        
    }
});

var DupWaterMark = React.createClass({
    render: function() {
        let dupImg = content.CUSTOMER.offers;
        if(dupImg.hasOwnProperty("dupWatermark"))
        {
            return (
                <div className="watermarkStyle"><img width="100%" height="100%" src={dupImg.dupWatermark}/></div>
            );
        }
        else {
            return null;
        }

    }
});

class App extends React.Component {

    constructor(props) {
        super(props);
        this.state = {};
        //this is for debug only, skip login dialog and goes to first tab immediately
        setTimeout(()=> {
            this.decodeData("qwe", "qweqwe");
        }, 10);
    }

    dynFooter(){
        let customer = content.CUSTOMER;
        if(customer.hasOwnProperty("statementType")){
            sType = customer.statementType;
        }
        if(sType==101 || sType==102 || sType==103 || sType==104 || sType==201){
            return "footerProspStyle";
        }
        else{
            return "footerFirstStyle";
        }
    }

    componentDidMount()
    {
        var url = window.location.href;//"file:///D:/facebook/YesBank/build/index.html?p1=dup&p2=ib#/"; // or window.location.href for current url
        var capturedP1 = "";
        var capturedP2 = "";
        var resCapturedP1 = url.match(/p1/g);
        var resCapturedP2 = url.match(/p2/g);

        if(resCapturedP1 != null){
            capturedP1 = /p1=([^&]+)/.exec(url)[1];
        }
        if(resCapturedP2 != null){
            capturedP2 = /p2=([^&]+)/.exec(url)[1];
        }

        if(capturedP2 === "AE4736231BB94A28#/")
        {
            urlResult = "ib";
        }
        else if(capturedP1 === "DFD344B10466D628")
        {
            urlResult = "dup"
        }
        else
        {
            urlResult = "org"
        }
    }

    isPromo(){
        if(urlResult === "org")
        {
            return <PromoLi/>;
        }
        else if(urlResult === "dup")
        {
            return null
        }
        else{
            return null;
        }
    }

    isDuplicate(){
        if(urlResult === "dup")
        {
            return <DupWaterMark/>;
        }
        else{
            return null;
        }
    }


    decodeData(username, password) {
        if (loadContent(username, password)) {
            this.setState({error: null, data: content});
            this.context.router.transitionTo("dashboard");
        } else {
            console.log("!!");
            this.setState({error: "Username or password mismatch", data: null});
        }
    }

    mainContainerDyn() {
        if (navigator.userAgent.match(/iPhone/i)) {
            return "containerPaddingm"
        }
        else  if (navigator.userAgent.match(/Android/i))
        {
            return "containerPaddingm"
        }
        else  if (navigator.userAgent.match(/BlackBerry/i)) {
            return "containerPaddingm"
        }
        else if (navigator.userAgent.match(/webOS/i)) {
            return "containerPaddingm"
        }
        else {
            return "containerPadding"
        }
    }

    navViewDyn() {
        if (navigator.userAgent.match(/iPhone/i)) {
            return "navMobIcon"
        }
        else  if (navigator.userAgent.match(/Android/i))
        {
            return "navMobIcon"
        }
        else  if (navigator.userAgent.match(/BlackBerry/i)) {
            return "navMobIcon"
        }
        else if (navigator.userAgent.match(/webOS/i)) {
            return "navMobIcon"
        }
        else {
            return "nav nav-tabs"
        }
    }

    formatCurrency(nStr)
    {
        nStr += '';
        var x = nStr.split('.');
        var x1 = x[0];
        var x2 = x.length > 1 ? ('.' + x[1]): '';
        if
        (
            x2.length == 0)
        {
            x2 = '.00';
        }
        else if
        (
            x2.length == 2)
        {
            x2 = '.' + x[1] + '0';
        }

        var rgx = /(\d+)(\d{3})/;
        var z = 0;
        var len = String(x1).length;
        var num = parseInt((len/2)-1);

        while (rgx.test(x1))
        {
            if(z > 0)
            {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            }
            else
            {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
                rgx = /(\d+)(\d{2})/;
            }
            z++;
            num--;

            if(num == 0)
            {
                break;
            }
        }
        return x1+x2;
    }


    onPrint() {
        let customer = content.CUSTOMER;
        if(customer.hasOwnProperty("statementType")){
            sType = customer.statementType;
        }
        if(sType == 103 || sType == 104)
        {
            earned = "Cashback Earned :";
        }
        else
        {
            earned = "Points Earned :";
        }
        //var MyCardPage = content.CUSTOMER.myCardPage;
        var statementtable = [];
        if(customer.hasOwnProperty("myCardPage")){
            var MyCardPage = content.CUSTOMER.myCardPage;
            if(MyCardPage.hasOwnProperty("TransactionsInfo")) {
                let TransactionsInfo = MyCardPage.TransactionsInfo
                if (TransactionsInfo.hasOwnProperty("transaction")) {
                    let tempStatementtable = TransactionsInfo.transaction;
                    let newTransactionData = [];
                    if(tempStatementtable.length > 1)
                    {
                        for(var sdate in tempStatementtable)
                        {
                            let zTransaction = tempStatementtable[sdate];
                            let zdate = zTransaction.transactionDate;
                            zdate = (zdate).split("-");
                            zdate = zdate[2]+zdate[1]+zdate[0];
                            newTransactionData.push({
                                sortDate:(zTransaction.amount==0)?"":zdate,
                                transactionDate:zTransaction.transactionDate,
                                transactionCode:zTransaction.transactionCode,
                                description:zTransaction.description,
                                CardSequenceNumber:zTransaction.CardSequenceNumber,
                                amount:(zTransaction.amount==0)?"":zTransaction.amount,
                                transactionType:zTransaction.transactionType,
                            })
                        }
                    }
                    else{
                        let zTransaction = tempStatementtable;
                        let zdate = zTransaction.transactionDate;
                        zdate = (zdate).split("-");
                        zdate = zdate[2]+zdate[1]+zdate[0];
                        newTransactionData.push({
                            sortDate:(zTransaction.amount==0)?"":zdate,
                            transactionDate:zTransaction.transactionDate,
                            transactionCode:zTransaction.transactionCode,
                            description:zTransaction.description,
                            CardSequenceNumber:zTransaction.CardSequenceNumber,
                            amount:(zTransaction.amount==0)?"":zTransaction.amount,
                            transactionType:zTransaction.transactionType,
                        })
                    }
                    statementtable = newTransactionData;
                }
                else
                {
                    statementtable = fdStatementTablePrint;
                }
            }
            else
            {
                statementtable = fdStatementTablePrint;
            }
        }


        let homePageData = content.CUSTOMER;
       /* let dataToPrint = _.map(statementtable, function(item){
            return _.omit(item, ['transactionType', "cashBackFlg","CardSequenceNumber","CardHolderName","transactionCode","smartEmi","Exchange"]);
        });*/

        //let logoPrint = "<div className=\"watermarkStyle\"><img src="+content.CUSTOMER.bannersImg+"/></div>";

        printFirst(statementtable,homePageData,earned,urlResult);

        /*
        For First Print
         printFirst(dataToPrint,homePageData);

        For Prosperity Print
         printProsp(dataToPrint,homePageData);
        */
    }

    onDownload(){

    }

    render() {
        if (this.state.data) {

            var route = this.context.router.getCurrentRoutes()[1];
            var name = route.name;
            var customer = content.CUSTOMER;
            var headerImg = "";
            var logo = "";
            if(customer.hasOwnProperty("bannersImg"))
            {
                headerImg = customer.bannersImg;
                if(headerImg.hasOwnProperty("logo"))
                {
                    logo = headerImg.logo;
                }
            }
            if(customer.hasOwnProperty("printpath"))
            {
                let printpath = customer.printpath;
                if(printpath.hasOwnProperty("printpathlocation"))
                {
                    pdfDownloadLink = "D:/prints/"+printpath.printpathlocation;
                }
            }

            return (

                <div className={this.mainContainerDyn()}>
                    <div className="innerMainContainer">
                        <div className="row">
                            <div className="tabNavMargin"><img width="100%" src={logo}/></div>
                        </div>
                        <br/>
                        <div className="containerleft">
                            <MediaQuery minDeviceWidth={320}>
                                <MediaQuery maxDeviceWidth={959}>
                                    <div className="row">
                                        <Search/>
                                    </div>
                                </MediaQuery>
                            </MediaQuery>
                            <MediaQuery minDeviceWidth={960}>
                                <MediaQuery maxDeviceWidth={1824}>
                                    <div className="row">
                                        <div className="col-md-10">
                                            <ul className="customNavtab">
                                                <li id="overviewTab"  role="presentation">
                                                    <Link to="dashboard" className="linkAnchor">SUMMARY</Link>
                                                </li>
                                                <li  id="myCardTab" role="presentation">
                                                    <Link to="credit" className="linkAnchor">STATEMENT DETAILS</Link>
                                                </li>
                                                <PromoLi/>
                                                <li  id="termsTab"  role="presentation">
                                                    <Link to="terms" className="linkAnchor">TERMS &amp; CONDITIONS</Link>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="col-md-1">
                                            <div className="printIcon" onClick={this.onPrint.bind(this)}></div>
                                        </div>
                                        <div className="col-md-1">

                                        </div>
                                    </div>
                                </MediaQuery>
                            </MediaQuery>
                        </div>
                        <div id="tabContentContainer" className="tab-content contentDiv">
                            <RouteHandler data={this.state.data}/>
                            {this.isDuplicate()}
                        </div>
                    </div>
                    <div className={this.dynFooter()}>
                        <div className="col-md-6">
                            <div className="footerAddress">YES BANK Limited</div>
                        </div>
                        <div className="col-md-3">
                            <div className="row">
                                <a href="https://www.facebook.com/YESBANK/" target="_blank"><button className="fbIcon"></button></a>
                                <a href="https://www.twitter.com/yesbank" target="_blank"><button className="twitterIcon"></button></a>
                                <a href="https://www.instagram.com/yes_bank" target="_blank"><button className="instaIcon"></button></a>
                            </div>
                        </div>
                        <div className="col-md-3"><h4>Visit us at <b><a href="https://www.yesbank.in" target="_blank">www.yes.bank</a></b></h4></div>
                    </div>
                </div>
            );
        } else {
            return <Login onLogin={this.decodeData.bind(this)} error={this.state.error}/>
        }
    }
}

App.contextTypes = {
    router: React.PropTypes.func
};

var routes = (
    <Route handler={App} path="/">
        <DefaultRoute name="dashboard" handler={Dashboard}/>
        <Route name="credit" handler={CreditForm}>
            <DefaultRoute name="credit-transaction" handler={CreditForm.CraditT}/>
            <Route name="my_reward" handler={CreditForm.MyReward}/>
        </Route>
        <Route name="offers" handler={OffersForm}/>
        <Route name="terms" handler={TermsForm}/>

    </Route>
);

//var HashLocation = require("./PatchedRouterHashLocation");
Router.run(routes, function (Handler) {
    let appHost = document.getElementById('app');
    render(<Handler/>, appHost);
});